# Agenda Fácil

Este é o repositório oficial do aplicativo **Agenda Fácil**, criado para facilitar o agendamento de clientes para manicures, barbeiros e profissionais autônomos.

## Funcionalidades principais

- Cadastro de clientes
- Agendamento de horários
- Notificações de lembrete
- Login para profissional e cliente
- Integração com WhatsApp
- Pagamentos via Pix, Cartão ou Mercado Pago
- Histórico de agendamentos

---

Feito com ❤️ usando React Native + Firebase.
